package edu.uah.cpe.traintrax;



/* Class is used to retrieve and set fields for the Settings Menu */

final public class MainSettings
{
        /* Private variable for total bill amount */
        private int interval;
        /* private variable for tip percentage */
        private int radius;
        /* private variable for number of people to split the bill with */
        private Boolean intervalFlag;

        /* Gets the search interval value (min) */
        public int getInterval(){return interval;}

       /* Gets the search radius value (km) */
        public int getRadius(){return radius;}

       /* Gets the intervalFlag  */
        public Boolean getintervalFlag(){return intervalFlag;}

        /* Sets the search interval value */
        public void setInterval(int interval){
            this.interval = interval; }

        public void setRadius(int radius){
        this.radius = radius; }

        public void setintervalFlag(Boolean intervalFlag){
        this.intervalFlag = intervalFlag; }

        /**
         * Constructor
         * @param interval
         * @param radius
         * @param intervalFlag
         */

        /* Default Constructor */
        public MainSettings() {
            //set to a default interval of 5 mins and radius of 1km
            this.interval = 5;
            this.radius = 1;
            this.intervalFlag = false;
        }

    }
