-----------------------------------------------------------
GSon - A Java library to convert JSON to Java objects 
       and vice-versa
-----------------------------------------------------------

"Gson is a Java library that can be used to convert Java 
Objects into their JSON representation. It can also be used
 to convert a JSON string to an equivalent Java object. 
Gson can work with arbitrary Java objects including 
pre-existing objects that you do not have source-code of. "

For more information:
http://code.google.com/p/google-gson/