-----------------------------------------
Jackson - High-performance JSON processor
-----------------------------------------

"Jackson is a streaming (reading, writing), FAST (measured to be 
faster than any other Java JSON parser and data binder), powerful 
(full data binding for common JDK classes as well as any Java bean 
class, Collection, Map or Enum), zero-dependency (does not rely on 
other packages beyond JDK), Open Source (LGPL or AL) and fully 
conformant."

For more information:
http://jackson.codehaus.org/
